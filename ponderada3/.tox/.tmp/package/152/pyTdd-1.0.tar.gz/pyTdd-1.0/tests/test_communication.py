import os
import pytest
from dotenv import load_dotenv
import subprocess
import time

load_dotenv()

@pytest.fixture(scope="module")
def mqtt_processes():
    # Caminhos ajustados conforme necessário
    publisher_script = "../src/publisher.py"
    subscriber_script = "../src/subscriber.py"

    # Inicia o subscriber
    subscriber_process = subprocess.Popen(["python", subscriber_script], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

    # Espera pelo arquivo de sinalização
    while not os.path.exists("subscriber_ready_signal.txt"):
        time.sleep(1)

    # Inicia o publisher
    publisher_process = subprocess.Popen(["python", publisher_script], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    publisher_process.wait()

    # Captura a saída do subscriber
    subscriber_output, _ = subscriber_process.communicate(timeout=10)
    subscriber_process.terminate()

    # Limpeza
    if os.path.exists("subscriber_ready_signal.txt"):
        os.remove("subscriber_ready_signal.txt")

    yield subscriber_output

def test_recebimento(mqtt_processes):
    expected_message = "Hello"
    assert expected_message in mqtt_processes, "A mensagem esperada não foi recebida pelo subscriber."
